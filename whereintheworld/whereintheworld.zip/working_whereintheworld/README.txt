IMPLEMENTATION
All of the APIs perform according to the specifications both on localhost and herokuapps.
I don't sort the locations when I get them out of the mongo collection; but so far the documents have been inserted and retrieved in the correct order, so I haven't bothered to sort them.
For the reverse geocoding, I'm pretty sure that I was supposed to use the Google Maps API, but I couldn't figure out how to get around the "5 queries per second" limit. So I used a different API.

COLLABORATORS
Mathurshan Vimalesvaran
George Brown

TIME SPENT
~10 hours