// Outside API initialization
var express = require('express');
var app = express();
var bodyParser = require('body-parser')
var Geocodio = require('geocodio');

app.use(bodyParser.urlencoded({
    extended: true
}));

// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = process.env.MONGOLAB_URI ||
    process.env.MONGOHQ_URL ||
    'mongodb://localhost/whereintheworld'; // comp20 is the name of the database we are using in MongoDB
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
    db = databaseConnection;
});


//            INSERTS DATA AND RETURNS LAST 100 STUDENTS            //

app.post('/sendLocation', function (request, response) {

    response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "X-Requested-With");
    response.set('Content-Type', 'application/json');

    var login = request.body.login;
    var lat   = request.body.lat;
    var lng   = request.body.lng;

    if (login != undefined && lat != undefined && lng != undefined) {
        mongo.connect(mongoUri, function(err, db) {
            var date = Date();

            insertStudent(db, login, lat, lng, date);
        });
    } else {
        response.send('');
    }

    var insertStudent = function(db, login, lat, lng, date) {
        var collection = db.collection('locations');

        collection.insert([
            { "login" : login            , "created_at" : date,
              "lng"   : parseFloat(lng)  , "lat"        : parseFloat(lat) }
        ], function(err, result) {
            returnLocations(db);
        });
    }

    var returnLocations = function(db) {
        var students = '';

        db.collection('locations', function(er, collection) {
            collection.find().toArray(function(err, cursor) {
                for (var count = cursor.length - 1; count >= 0 ; count--) {

                    if (cursor.length - count > 100) break;

                    students = students + JSON.stringify(cursor[count]);

                    if (count > 0 && ( (cursor.length - count) < 100)) {
                        students = students + ", ";
                    }
                }
                students = '{"characters":[],"students":[' + students + ']}';
                response.send(students);
            });
        });
    }

});


//                 RETURNS LOCATIONS FROM QUERY                 //

app.get('/locations.json', function (request, response) {

    response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "X-Requested-With");
    response.set('Content-Type', 'application/json');

    var login = request.query.login;

    if (login == undefined) {
        response.send('[]');
    } else {
        getLocations(login);
    }

    function getLocations(login) {
        mongo.connect(mongoUri, function(err, db) {
            var logins = '';

            db.collection('locations', function(er, collection) {
                collection.find( { "login": login } ).toArray(function(err, cursor) {
                    for (var count = cursor.length - 1; count >= 0 ; count--) {

                        logins = logins + JSON.stringify(cursor[count]);

                        if (count > 0) {
                            logins = logins + ", ";
                        }
                    }

                    if (logins == '' ) {
                        response.send('[]');
                    } else {
                        logins = '[' + logins + ']';
                        response.send(logins);
                    }

                });
            });
        });
    }

});


//                        INDEX PAGE                          //

app.get('/', function (request, response) {

    response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "X-Requested-With");
    response.set('Content-Type', 'text/html');

    var allStudents = new Array;
    var coordinates = new Array;

    mongo.connect(mongoUri, function(err, db) {
        db.collection('locations', function(er, collection) {
            collection.find().toArray(function(err, cursor) {
                for (var count = cursor.length - 1; count >= 0 ; count--) {
                    var newS = cursor[count];
                    var newEntry = "<p>Timestamp: " + newS['created_at'] 
                                   + "<br/>Login: " + newS['login'];

                    allStudents[cursor.length - count - 1] = newEntry;
                    coordinates[cursor.length - count - 1] = cursor[count]['lat'] + ',' + cursor[count]['lng'];
                }
                geocode(allStudents, coordinates);
            });
        });
    });

    function geocode(allStudents, coordinates) {
        var config = {
            api_key: '5aa66a46bfa4bbc5646c4aa2459ca60a4f2f5aa'
        }

        var geocodio = new Geocodio(config);

        geocodio.reverse(coordinates, function(err, address_sets){
            if (err) throw err;
            concatData(allStudents, coordinates, address_sets);
        });
    }
    
    function concatData(allStudents, coordinates, addresses) {
        for (var i = 0; allStudents[i]; i++ ) {
            console.log(addresses['results'][i]['response']['results']);

            // either adds geolocated address or latlng
            if (addresses['results'][i]['response']['results'][0]) {
                var address = addresses['results'][i]['response']['results'][0]['formatted_address'];
                console.log(address);
                allStudents[i] = allStudents[i] + "<br/>Address: " + address + "</p>";
            } else {
                allStudents[i] = allStudents[i] + "<br/>LatLng: " + coordinates[i] + "</p>";
            }
            
        }
        sendHTML(allStudents);
    }

    function sendHTML(allStudents) {
        var page = "<!DOCTYPE HTML><html><head><title>Index</title></head><body>";

        for (var i = 0; allStudents[i]; i++) {
            page = page + allStudents[i];
        }
        page = page + "</body></html>";

        response.send(page);
    }
});


//                   RETURNS REDLINE TRAIN INFO                 //

app.get('/redline.json', function (request, response) {

    response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "X-Requested-With");
    response.set('Content-Type', 'application/json');

    var data    = '';
    var http    = require('http');
    var options = {
        host: 'developer.mbta.com',
        port: 80,
        path: '/lib/rthr/red.json'
    };

    http.get(options, function(res) {
        res.on("data", function(chunk) {
            data = data + chunk;
        });
        res.on("end", function() {
            response.send(data);
        });
    }).on('error', function(e) {
        response.send('');
    });
});


// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);